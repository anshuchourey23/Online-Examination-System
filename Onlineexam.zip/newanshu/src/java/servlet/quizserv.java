/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.sql.*;

/**
 *
 * @author HP
 */
public class quizserv extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   //protected void processRequest(HttpServletRequest request, HttpServletResponse response)
       //     throws ServletException, IOException {
     //   response.setContentType("text/html;charset=UTF-8");
     //  PrintWriter out = response.getWriter();
      //  try {
            /* TODO output your page here. You may use following sample code. */
        //    out.println("<!DOCTYPE html>");
         //   out.println("<html>");
         //  out.println("<head>");
         //   out.println("<title>Servlet quizserv</title>");            
          //  out.println("</head>");
          //  out.println("<body>");
         //   out.println("<h1>Servlet quizserv at " + request.getContextPath() + "</h1>");
           // out.println("</body>");
      //      out.println("</html>");
    //    } finally {
      //      out.close();
     //   }
  //  }
        

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        
        Connection con=null;
        
  
        String id=request.getParameter("id");
        String name=request.getParameter("name");
        String opt1=request.getParameter("opt1");
        String opt2=request.getParameter("opt2");
        String opt3=request.getParameter("opt3");
        String opt4=request.getParameter("opt4");
        String answer=request.getParameter("answer");
        
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/oems","root","root");
            
             PreparedStatement ps=con.prepareStatement("insert into question values(?,?,?,?,?,?,?)");
            ps.setString(1, id);
            ps.setString(2, name);
            ps.setString(3, opt1);
            ps.setString(4, opt2);
            ps.setString(5, opt3);
            ps.setString(6, opt4);
            ps.setString(7, answer);
         ps.executeUpdate();
         response.sendRedirect("entry.jsp");
        }
        catch(Exception e)
        {
            System.out.println("Sorry!!Try again!!!");
        }
    }
    
    
    

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

  

}
