/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.*;

/**
 *
 * @author HP
 */
public class anshu extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String paraname,paravalue[];
        Connection con;
        Statement st;
        ResultSet rs;
        int cnt=0;
        String answer="";
        Enumeration paranames=request.getParameterNames();
        try {
            /* TODO output your page here. You may use following sample code. */
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/oems","root","root");
            st=con.createStatement();
               String str;
              for(int j=1;j<6;j++)
                    { 
                     //String s=Integer.toString(i);
                    // System.out.println(i);
            //   String sql="select  id from question where id=i";
             //  ResultSet rs1=st.executeQuery("select id from question where id='"+i+"'");
               //st.setString(1,s);
              //  st = con.prepareStatement(sql);
                        
                      // str=String.valueOf(j);
                      // out.println(str);
        String q2=request.getParameter("ID");
      //  String opt2=request.getParameter("opt2");
       // String opt3=request.getParameter("opt3");
       // String opt4=request.getParameter("opt4");
     out.println(q2);
                 
                 rs = st.executeQuery("select answer from question where id='"+j+"'");
                    // out.println("<html>");
          out.println("  <body background=\"image\\student background.jpg\"\n" +
"          style=\"background-repeat:no-repeat;background-size:100%100%\">");
         
         // out.println("<hr>");
              rs.next();
              String s1=rs.getString(1);
             // out.println(s1);
             
          if(s1==q2)
              {
               cnt++;
              }
                    }
              out.println("you have scored "+ cnt);
                    
                    }catch(Exception e){
            out.println("Sorry Try Again");
    }
    }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
 
}
