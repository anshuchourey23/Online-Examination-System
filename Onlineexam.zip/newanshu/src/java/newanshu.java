/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author HP
 */
public class newanshu extends HttpServlet {
      private Connection con;
    private Statement st;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        //response.setContentType("text/html;charset=UTF-8");
       // PrintWriter out = response.getWriter();
        
              
              
    
              
               try{
                    Class.forName("com.mysql.jdbc.Driver");
                     con=DriverManager.getConnection("jdbc:mysql://localhost:3306/oems","root","root");
                       Statement st=con.createStatement();           
                     out.println("<h3> Select options</h3>");
                     String str="";
                    for(int i=1;i<6;i++)
                    { 
                     String s=Integer.toString(i);
                     System.out.println(i);
            //   String sql="select  id from question where id=i";
               ResultSet rs1=st.executeQuery("select id from question where id='"+i+"'");
               //st.setString(1,s);
              //  st = con.prepareStatement(sql);
             
                   
                    ResultSet rs=st.executeQuery("select *from question where id='"+i+"'");
                     out.println("<html>");
          out.println("  <body background=\"image\\student background.jpg\"\n" +
"          style=\"background-repeat:no-repeat;background-size:100%100%\">");
         
          out.println("<br>");
          rs.next();
              String s1=rs.getString(1);
              String s2=rs.getString(2);
              String s3=rs.getString(3);
              String s4=rs.getString(4);
              String s5=rs.getString(5);
              String s6=rs.getString(6);
              String s7=rs.getString(7);
              //out.println("<a href=id?code="+i+">");
              out.println(s1);
              out.println(s2);
              
             
             
              out.println("<table>");
               // out.println("<br><br>");
                  // out.println( "<tr>");
                        //out.println("<td>question id</td>");
                       // out.println("<td ><input type=\"text\" name=\"id\" placeholder=\"id\"></td>");
                  // out.println("</tr>"); 
               //   out.println("<tr>");  
                  //     out.println(" <td>Question</td>"); 
                 //     out.println("<td><input type=\"text\" name=\"name\" placeholder=\"name\"></td>");  
               //   out.println("</tr>");  
                   out.println("<tr>"); 
                      str=String.valueOf(i);
                       
                        out.println("<div><td><input type=\"radio\" name=\"'"+i+"'\" id=\"i\" onclick=\"getAnswer('opt1')\"value=\"opt1\"></td></div>");
                        String o1=Integer.toString(i);
                        out.println(" <td>");
                       out.println(s3);
                        out.println(" </td>");
                    out.println("</tr>");
                 
                    out.println("<tr>");
                       // out.println("<td>Option2</td>");
                       
                       out.println("<div><td><input type=\"radio\" name=\"'"+i+"'\" id=\"i+1\" onclick=\"getAnswer('opt2')\"value=\"opt2\" ></td></div>"); 
                       out.println(" <td>");
                       out.println(s4);
                        out.println(" </td>");
                   out.println(" </tr>");
                    
                   out.println("<tr>"); 
                      // out.println("<td>Option3</td>"); 
                      
                       out.println("<div><td><input type=\"radio\" name=\"'"+i+"'\" id=\"i+2\" onclick=\"getAnswer('opt3')\" value=\"opt3\" ></td></div>"); 
                       out.println(" <td>");
                       out.println(s5);
                        out.println(" </td>");
                   out.println(" </tr>");
                    
                   out.println("<tr>"); 
                      // out.println("<td>Option4</td>"); 
                      
                        out.println("<div><td><input type=\"radio\" name=\"'"+i+"'\" id=\"i+3\"  value=\"opt4\" ></td></div>");
                        out.println(" <td>");
                       out.println(s5);
                        out.println(" </td>");
                    out.println("</tr>");
                     
                    
                    // out.println("<table>");
                    
                  
               out.println("</table>"); 
             //  out.println("<form>");
              out.println("</a>");
              
          
         
          out.println("</body>");
          out.println("</html>");
          String A=Integer.toString(i);
                   out.println("<a href=anshu?ID="+A+"></a>");
                    
                    }
                     out.println("<html>");
                     out.println("<body>");
                     out.println("<form action=\"anshu\">  "); 
                      out.println("<table>");
                    out.println("<tr>");
                        out.println("<td colspan=\"2\" style=\"text-align: center\"><input type=\"submit\"></td>");
                    out.println("</tr>");
                     out.println("</table>"); 
               out.println("</form>");
            
          
         
          out.println("</body>");
          out.println("</html>");
                     
                    
                     
          con.close();
          
               }catch(Exception e){
                   out.println(e);
               }
    }

    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
   

}
